var userid = getCookie("userid");
var userimg= getCookie("userimg");
var username= getCookie("username");


$(function () {

    $(".nav-hover").mouseover(function () {
        $(".nav-hover").addClass("open")
    })
    $(".dropdown-menu").mouseout(function () {
        $(".nav-hover").removeClass("open")
    })

    $(".navbar-toggle").click(function () {
        var obj = $(".navbar-collapse");
        if (!obj.hasClass("in")){
            obj.addClass("in");
        } else {
            obj.removeClass("in")
        }

    })

    if (userid && userimg && username) {
        $("#nav_usercenter_bar img").attr("src", userimg);
        $("#nav_usercenter_bar img").attr("alt", username);
        $("#nav_usercenter_bar span").html(username);
        $("#nav_usercenter_bar").show();
        $("#nav_login_bar").hide();


        $("#login").hide();
        $("#user").removeClass("hide");
        $("#userimg img").attr("src",userimg);

    }


    $("#More").click(function() {
        $(".TopButtonsBG").is(":hidden") ? ($(".TopButtonsBG").show(), navigator.userAgent.match(/UCBrowser/ig) ? $(".TopButtons").show() : $(".TopButtons").slideDown()) : ($(".TopButtonsBG").hide(), navigator.userAgent.match(/UCBrowser/ig) ? $(".TopButtons").hide() : $(".TopButtons").slideUp());
        return !1
    });
    $(".TopButtonsBG").click(function() {
        $(".TopButtonsBG").hide();
        $(".TopButtons").slideUp()
    });


    var length = $(".full p").length;
    if (length > 30) {
        var len = Math.ceil(length / 3);
        $(".full p:lt(15)").removeClass("none");
        $(".full p:gt(" + (3 * (len - 5) - 1) + ")").removeClass("none");
        $(".full p").eq(14).after('<p class="fulltip">································ 查看全部' + length + "章節 ································</p>")
    } else {
        $(".full p").removeClass("none")
    }

    $(".fulltip").on("click", function() {
        $(this).remove();
        $(".full p").removeClass("none")
    });
});





function addComment (bookid) {
    if (userid && username) {
        var comment = $("#comment").val();
        if (comment.length > 5){
            $.post(apiurl+"/user/addcomment",{"username":username,"userid":userid,"bookid":bookid,"comment":comment},function(data){

                if(data.code==200){

                    alert(data.msg);

                }else{
                    alert("操作失败:"+data.msg);
                }
            },"json");
        } else {
            alert("操作失败:不得少於5個字");
        }
    }else {
        alert("还没登录")
    }

}



function sendtoken(token){

    $.post(apiurl + "/user/sendtoken",{"token":token},function(data){

        if(data.code==200){
            setCookie("userid",data.data.UserId,7);
            setCookie("username",data.data.UserName,7);
            setCookie("userimg",data.data.UserImg,7);

            window.location.href="/user/mark"
        }else{
            alert(data.msg);
        }
    },"json");
}


function addmark(bookId){
    var userid = getCookie("userid");
    $.post(apiurl+ "/user/addmark",{"bookid":bookId,"userid":userid},function(data){
        if(data.code==200){
            alert(data.msg);
        }else{
            alert(data.msg);
        }
    },"json");
}

function addcase(bookid,chapterid,chaptername) {
    var userid = getCookie("userid");
    $.post(apiurl+"/user/addmark",{"bookid":bookid,"userid":userid,"chapterid":chapterid,"chaptername":chaptername},function(data){
        if(data.code==200){
            alert(data.msg);
        }else{
            alert(data.msg);
        }
    },"json");
}

function delmark(bookId){

    $.post(apiurl+"/user/delmark",{"bookid":bookId,"userid":userid},function(data){
        if(data.code==200){
            window.location.href="/user/mark";
        }else{
            alert(data.msg);
        }
    },"json");
}


function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookie(name, value, days) {
    var d = new Date;
    d.setTime(d.getTime() + 24*60*60*1000*days);
    document.cookie = name + "=" + value + ";path=/;expires=" + d.toGMTString();
}

function getComments(bookid) {
    var commentDiv = $("#commentList");
    var morecommentDiv = $("#MoreComment");
    var page =morecommentDiv.data("page");
    var counts = morecommentDiv.data("count");

    if (page > Math.ceil(counts / 20)) {
        return ;
    }
    var itemHtml=""
    $.get(apiurl + "/comments/"+ bookid +"/"+page,function(data){
        if(data.code==200){
            data.data.Comments.forEach(function (obj) {
                itemHtml +='<div><ul class="HuabenListUL CommentUL" >\n' +
                    '                    <li class="CommentUser" >\n' +
                    '                        <p class="text-center" >\n' +
                    '                            <img src="'+ obj.UserImg+ '" class="userPic" >\n' +
                    '                        </p>\n' +
                    '                        <p class="text-center" >\n' +
                    '                            <span  class="vipNickName" >'+ obj.UserName+'</span>\n' +
                    '                        </p>\n' +
                    '                    </li>\n' +
                    '                    <li class="CommentRight" >\n' +
                    '                        <div class="CommentContent" >\n' +
                    '                            <div class="discription" >\n' +
                    '                                <p class="dp" >\n'+ obj.Content+'\n' +
                    '                                </p>\n' +
                    '                            </div>\n' +
                    '                        </div>\n' +
                    '                        <ul class="HuabenListUL CommentBottomNav text-right" \n' +
                    '                            <li class="CommentUpdateTime" >\n' +
                    '                                <p class="text-lightgrey" >\n'+ obj.UpdateTime +'</p>\n' +
                    '                            </li>\n' +
                    '                            <li ><button onclick="addlike(\''+ obj.CommentId+'\',\'add\')" ><i class="comment-heart-empty" ></i><span >讚(</span><span >'+obj.Like+'</span><span >)</span></button></li>\n' +
                    '                            <li ><button onclick="addlike(\''+obj.CommentId+'\',\'dis\')"><i class="comment-comments-alt" ></i><span >踩(</span><span >'+obj.DisLike+'</span><span >)</span></button></li>\n' +
                    '                        </ul>\n' +
                    '                    </li>\n' +
                    '                </ul></div>'
            });
            commentDiv.append(itemHtml)
            morecommentDiv.data("page",page + 1);
        }
    },"json");
}


function getComments_mobile(bookid) {
    var commentDiv = $("#mobileComments");
    var morecommentDiv = $("#MoreCommentMobile");
    var page =morecommentDiv.data("page");
    var counts = morecommentDiv.data("count");
    if (page > Math.ceil(counts / 20)) {
        return ;
    }
    var itemHtml=""
    $.get(apiurl + "/comments/"+ bookid +"/"+page,function(data){
        if(data.code==200){
            data.data.Comments.forEach(function (obj) {
                itemHtml +='<div >\n' +
                    '                    <ul class="HuabenListUL CommentTopNav" >\n' +
                    '                    <li ><img src="'+ obj.UserImg+ '" class="userPic" ></li>\n' +
                    '                <li >\n' +
                    '                <p >'+obj.UserName+'</p>\n' +
                    '                <p class="text-lightgrey" >'+obj.UpdateTime+'</p>\n' +
                    '                    </li>\n' +
                    '                </ul>\n' +
                    '                    <div class="CommentContent" >\n' +
                    '                    <div class="discription" >\n' +
                    '                    <p class="dp" >'+obj.Content+'</p>\n' +
                    '                    </div>\n' +
                    '                    </div>\n' +
                    '                    <ul class="HuabenListUL CommentBottomNav" >\n' +
                    '                    <li ><button onclick="addlike(\''+ obj.CommentId+'\',\'add\')"><img src="/static/img/like.png" ><span >'+obj.Like+'</span></button></li>\n' +
                    '                <li ><button onclick="addlike(\''+ obj.CommentId+'\',\'dis\')"><img src="/static/img/dislike.png" ><span >'+obj.DisLike+'</span></button></li>\n' +
                    '                </ul>\n' +
                    '                </div>'
            });
            commentDiv.append(itemHtml)
            morecommentDiv.data("page",page + 1);
        }
    },"json");
}


function addlike(cid,act) {
    $.post(apiurl + "/user/addlike",{"act":act,"commentid":cid},function(data){
        if(data.code==200){
            alert(data.msg);
        }else{
            alert(data.msg);
        }
    },"json");
}

function goto(url) {
    window.location.href=url;
}

function getCase(userid,bookid) {
    var CaseDiv = $("#BookCase");
    $.post(apiurl + "/user/getcase",{"userid":userid,"bookid":bookid},function(data){
        if(data.code==200){
            if (data.data.length > 5){
                CaseDiv.attr("href","/chapter/"+data.data);
                CaseDiv.removeClass("hide");
            }
        }
    },"json");
}

function getCaseMobile(userid,bookid) {
    var CaseDiv = $("#BookCase_Mobile");
    $.post(apiurl + "/user/getcase",{"userid":userid,"bookid":bookid},function(data){
        if(data.code==200){
            if(data.data.length > 5){
                itemHtml = '<li><span onclick="goto(\'/chapter/'+data.data+'\')">繼續閱讀</span></li>';
                CaseDiv.append(itemHtml)
            }

        }
    },"json");
}

function addStar(userid,bookid,start) {
    var CaseDiv = $("#BookCase");
    $.post(apiurl + "/user/addstar",{"userid":userid,"bookid":bookid,"star":start},function(data){
        if(data.code==200){
            alert(data.msg);
        } else {
            alert(data.msg);
        }
    },"json");
}


function onSignIn(googleUser) {
    // Useful data for your client-side scripts:
    //var profile = googleUser.getBasicProfile();
    // The ID token you need to pass to your backend:
    var id_token = googleUser.getAuthResponse().access_token;
    //sendtoken(id_token);
};

function onSignInLogin(googleUser) {
    // Useful data for your client-side scripts:
    //var profile = googleUser.getBasicProfile();
    // The ID token you need to pass to your backend:
    var id_token = googleUser.getAuthResponse().access_token;
    sendtoken(id_token);
};

//注销
function signOut() {
    gapi.load('auth2', function() {
        gapi.auth2.init();
    });
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
        setCookie("userid","");
        setCookie("username","");
        setCookie("userimg","");
        alert('用戶註銷成功');
        window.location.href="/login";
    });
}
