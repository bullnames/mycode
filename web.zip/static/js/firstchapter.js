if (992 > $(window).width()) {
    $(".Comment").insertAfter(".tabbar");
    $(".Comment").show();
    $(".aboutbook").insertAfter(".aboutbutton");
    $(".aboutbook").removeClass("hidden-xs").removeClass("hidden-sm");
    var h = $(".aboutbook").height();
    if (40 < h) {
        $(".aboutbook").height(40);
        var txt = "<div class='aboutmore' style='position:absolute;bottom:3px;right:10px;opacity:0.8;color:#666;background-color:#efefef;border-radius:13px;display:block;height:26px;width:26px;text-align:center;padding-top:4px;'><i class='icon-double-angle-down'></i></div>";
        $(".aboutbook").append(txt)
    }
} else if ($("#pc_bookinfo").show(), h = $(".aboutbook").height(), 40 < h && ($(".aboutbook").height(40), $(".aboutmore").show()), 0 < $(".similaritybook").length) {
    for (var html = "", i = 0; i < $(".similaritybook>div>div").length; i++) var div = $(".similaritybook>div>div")[i],
        tmpObj = $($(div).find("h5").next().html()),
        obj = {
            img: $(div).find(".cover").html(),
            title: $(div).find("h5").html(),
            author: '<a href="' + tmpObj.attr("href") + '" class="text-lightgrey text-left">' + tmpObj.text().replace(/\u4f5c\u8005\:/, "") + "</a>"
        },
        html = 3 > i ? html + ('<div class="hotList">\r\n' + obj.img + '<span class="order"><span class="no">' + (i + 1).toString() + "</span></span>\r\n<div><h4>" + obj.title + "</h4><p>" + obj.author + "</p></div></div>") : html + ('<div class="fansList">\r\n<label>' + (i + 1).toString() + '</label>\r\n<span class="nickName">' + obj.title + '</span>\r\n<span class="pull-right text-muted">' + obj.author + "</span></div>");
    $(".RankRight .fansBoard:nth-child(1) div").html(html)
}

function formatUpdateTime(a) {
    var c = new Date,
        b = a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate(),
        d = c.getFullYear() + "-" + (c.getMonth() + 1) + "-" + c.getDate();
    return c.getFullYear() != a.getFullYear() ? a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate() : b == d ? "\u4eca\u5929 " + a.getHours() + ":" + a.getMinutes() : 864E5 > (new Date(d)).getTime() - (new Date(b)).getTime() ? "\u6628\u5929 " + a.getHours() + ":" + a.getMinutes() : a.getMonth() + 1 + "-" + a.getDate()
}

function formatUpdateTimeV1(a) {
    var c = new Date,
        b = (c.getTime() - a.getTime()) / 1E3;
    return 3600 > b ? "\u521a\u521a" : 86400 > b ? parseInt(b / 3600) + "\u5c0f\u65f6\u524d" : 604800 > b ? parseInt(b / 86400) + "\u5929\u524d" : 2592E3 > b ? a.getMonth() + 1 + "-" + a.getDate() : 31104E3 > b ? a.getFullYear() == c.getFullYear() ? a.getMonth() + 1 + "-" + a.getDate() : a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate() : a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate()
}

function showFullAboutBook() {
    $(".aboutbook").css("height", "auto");
    $(".aboutmore").hide()
}


$(".aboutbook").click(function() {
    992 > $(window).width() && $(".aboutbook .aboutmore").is(":hidden") ? ($(".aboutbook").height(40), $(".aboutbook .aboutmore").show()) : showFullAboutBook()
});
$("#pc_bookinfo .cover").click(function() {
    var a = $("#pc_bookinfo .cover img");
    if (0 == a.length) return !1;
    var c = "?x-oss-process=image/resize,w_640";
    1024 < $(window).width() && 1.5 <= window.devicePixelRatio && (c = "?x-oss-process=image/resize,w_1280");
    var b = $.dialog({
        title: "",
        content: "<div class='text-center'><img style='max-width:100%;' id='bigCover' src='" + a.attr("src").replace(/(\?x\-oss\-process\=[^\@\?]+|\@\d+w)$/g, c) + "'/></div>",
        animation: "none",
        animationSpeed: 0,
        keyboardEnabled: !0,
        closeIcon: !1
    });
    $("#bigCover").load(function() {
        b.setDialogCenter()
    })
});
$(document).ready(function() {
    992 > $(window).width() && $(".footer").css("margin-bottom", "60px")
});

(function() {
    if (1024 < $(window).width() && 1.5 <= window.devicePixelRatio) {
        var a = $("#pc_bookinfo .biginfo .cover img")[0].src;
        a.match(/\@210w$/ig) && (a = a.replace(/\@210w$/ig, "?x-oss-process=image/resize,w_640"), $("#pc_bookinfo .biginfo .cover img")[0].src = a)
    }
})();